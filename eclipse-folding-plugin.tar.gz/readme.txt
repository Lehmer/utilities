Coffee Bytes Floding plugin:
To install simply copy features and plugins folders into the eclipse installation folder.
